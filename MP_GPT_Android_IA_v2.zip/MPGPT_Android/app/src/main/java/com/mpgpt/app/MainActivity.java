package com.mpgpt.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    final int RED=Color.rgb(215,25,32), BLACK=Color.rgb(8,8,8), WHITE=Color.WHITE, GRAY=Color.rgb(190,190,190), CARD=Color.rgb(22,22,22);
    EditText topic, endpoint; Spinner platform; LinearLayout results; String lastPost="";
    SharedPreferences prefs;
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextColor(WHITE); t.setTextSize(sp); t.setPadding(18,10,18,10); return t; }
    GradientDrawable bg(int c,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(c); g.setCornerRadius(r); return g; }
    Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(WHITE); b.setTextSize(15); b.setAllCaps(false); b.setBackground(bg(RED,28)); return b; }
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(BLACK); prefs=getSharedPreferences("mpgpt",0); build(); }

    void build(){
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(BLACK);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,12,18,28); scroll.addView(root);
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.mp_logo); logo.setAdjustViewBounds(true); root.addView(logo,new LinearLayout.LayoutParams(-1,230));
        TextView title=tv("MP GPT · IA PARA MENTIRAS PIADOSAS",20); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setTextColor(RED); root.addView(title);
        TextView sub=tv("Porque no toda verdad duele...  ·  Generación inteligente de contenido",13); sub.setTextColor(GRAY); root.addView(sub);
        root.addView(tv("TEMA DEL POST",13));
        topic=new EditText(this); topic.setHint("Ej.: cuando ella deja de discutir contigo"); topic.setHintTextColor(Color.rgb(100,100,100)); topic.setTextColor(WHITE); topic.setMinLines(2); topic.setPadding(18,12,18,12); topic.setBackground(bg(CARD,24)); root.addView(topic,new LinearLayout.LayoutParams(-1,110));
        root.addView(tv("PLATAFORMA",13));
        platform=new Spinner(this); String[] ps={"Facebook","Instagram","YouTube Shorts","TikTok"}; platform.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ps)); root.addView(platform,new LinearLayout.LayoutParams(-1,60));
        root.addView(tv("SERVIDOR DE IA",13));
        endpoint=new EditText(this); endpoint.setText(prefs.getString("endpoint","http://10.0.2.2:3000")); endpoint.setTextColor(WHITE); endpoint.setHint("https://tu-servidor.com"); endpoint.setSingleLine(true); endpoint.setPadding(18,10,18,10); endpoint.setBackground(bg(CARD,20)); root.addView(endpoint,new LinearLayout.LayoutParams(-1,60));
        TextView hint=tv("En emulador Android: http://10.0.2.2:3000. En teléfono real usa la URL HTTPS de tu servidor.",11); hint.setTextColor(GRAY); root.addView(hint);
        Button gen=button("✨  GENERAR CON IA"); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,62); gp.setMargins(0,14,0,8); root.addView(gen,gp);
        Button copy=button("📋  COPIAR TODO"); root.addView(copy,new LinearLayout.LayoutParams(-1,58));
        results=new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); root.addView(results);
        gen.setOnClickListener(v->generate()); copy.setOnClickListener(v->{ if(!lastPost.isEmpty()){ ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("MP GPT",lastPost)); Toast.makeText(this,"Contenido copiado",Toast.LENGTH_SHORT).show(); } });
        setContentView(scroll);
    }
    void add(String head,String body){ TextView h=tv(head,16); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); h.setTextColor(RED); results.addView(h); TextView t=tv(body,15); t.setTextIsSelectable(true); t.setBackground(bg(CARD,22)); results.addView(t); }
    void loading(boolean yes){ results.removeAllViews(); if(yes){ TextView t=tv("MP GPT está creando tu contenido con IA...",16); t.setTextColor(GRAY); results.addView(t); } }

    void generate(){
        String x=topic.getText().toString().trim(); if(x.isEmpty()){ topic.setError("Escribe un tema"); return; }
        String ep=endpoint.getText().toString().trim(); if(ep.isEmpty()){ endpoint.setError("Configura el servidor"); return; }
        prefs.edit().putString("endpoint",ep).apply(); String p=platform.getSelectedItem().toString(); loading(true);
        Executors.newSingleThreadExecutor().execute(()->{
            try{
                URL url=new URL(ep.replaceAll("/$","")+"/generate"); HttpURLConnection c=(HttpURLConnection)url.openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(90000); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=UTF-8");
                JSONObject req=new JSONObject(); req.put("topic",x); req.put("platform",p);
                try(OutputStream os=c.getOutputStream()){ os.write(req.toString().getBytes(StandardCharsets.UTF_8)); }
                int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream(); String body=read(is); if(code<200||code>=300) throw new Exception("Servidor: "+body);
                JSONObject j=new JSONObject(body); JSONObject d=j.getJSONObject("data");
                String post="TÍTULO SEO\n"+d.getString("title")+"\n\nTEXTO EVERGREEN\n"+d.getString("evergreen_text")+"\n\nDESCRIPCIÓN\n"+d.getString("description")+"\n\nPALABRAS CLAVE SEO\n"+d.getString("seo_keywords")+"\n\nHASHTAGS\n"+d.getString("hashtags")+"\n\nTEXTO PARA IMAGEN\n"+d.getString("image_text")+"\n\nPROMPT DE IMAGEN\n"+d.getString("image_prompt")+"\n\nCTA\n"+d.getString("cta");
                runOnUiThread(()->{ lastPost=post; results.removeAllViews(); add("TÍTULO SEO",d.optString("title")); add("TEXTO EVERGREEN",d.optString("evergreen_text")); add("DESCRIPCIÓN",d.optString("description")); add("PALABRAS CLAVE SEO",d.optString("seo_keywords")); add("HASHTAGS · "+p,d.optString("hashtags")); add("TEXTO PARA IMAGEN",d.optString("image_text")); add("PROMPT DE IMAGEN",d.optString("image_prompt")); add("CTA",d.optString("cta")); });
            }catch(Exception e){ runOnUiThread(()->{ results.removeAllViews(); add("ERROR",e.getMessage()==null?"No se pudo conectar con el servidor":e.getMessage()); }); }
        });
    }
    String read(InputStream is)throws Exception{ if(is==null)return "Sin respuesta"; BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8)); StringBuilder s=new StringBuilder(); String line; while((line=r.readLine())!=null)s.append(line); return s.toString(); }
}
