# MP GPT — Mentiras Piadosas · Android + IA real

Esta versión conecta la app Android a un servidor seguro que llama a la OpenAI Responses API. La clave de OpenAI NO se coloca dentro del APK.

## 1) Servidor de IA
Requisitos: Node.js 20+.

```bash
cd MPGPT_Server
npm install
```

Crea `.env` a partir de `.env.example` y configura `OPENAI_API_KEY`.
Luego:

```bash
npm start
```

En local quedará en `http://localhost:3000`.

## 2) Android Studio
Abre la carpeta `MPGPT_Android` en Android Studio y espera a que Gradle sincronice. Después usa:
**Build > Build APK(s)**.

## 3) Probar con emulador
En la app deja como servidor:
`http://10.0.2.2:3000`

## 4) Probar en teléfono físico
El teléfono debe poder llegar al servidor. Para producción, despliega `MPGPT_Server` en un hosting HTTPS y coloca esa URL en el campo **Servidor de IA** de la app.

## Qué genera MP GPT
- Título SEO
- Texto evergreen
- Descripción
- Palabras clave SEO
- Hashtags por plataforma
- Texto para imagen
- Prompt de imagen
- CTA con “sígueme”

El modelo se controla con `OPENAI_MODEL` y por defecto usa `gpt-5.6-luna`.
