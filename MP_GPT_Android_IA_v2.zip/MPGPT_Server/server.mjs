import express from 'express';
import cors from 'cors';
import OpenAI from 'openai';

const app = express();
app.use(cors());
app.use(express.json({limit:'32kb'}));
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.6-luna';

const instructions = `Eres MP GPT, el asistente editorial oficial de Mentiras Piadosas.
Marca: Mentiras Piadosas. Lema: “Porque no toda verdad duele...”.
Objetivo: crear publicaciones originales, humanas, profundas, directas y compartibles sobre relaciones, amor propio, desamor, límites, emociones y reflexiones de vida.
Reglas editoriales: no escribas como robot, evita frases genéricas y relleno, no repitas estructuras, no inventes estadísticas ni hechos. El texto evergreen debe seguir siendo útil aunque pasen meses o años y no depender de noticias o tendencias. SEO debe ser natural: palabras clave relacionadas con la intención de búsqueda, sin keyword stuffing. Los hashtags deben ser pocos y pertinentes a la plataforma elegida. La CTA debe incluir literalmente “sígueme” y una acción adicional.
El prompt de imagen debe ser profesional y coherente con Mentiras Piadosas; si pide a Nayla, descríbela como personaje femenino adulto ficticio y virtual, sin imitar a ninguna persona real.
Devuelve únicamente el JSON solicitado.`;

const schema = {
  type:'object', additionalProperties:false,
  properties:{
    title:{type:'string'}, evergreen_text:{type:'string'}, description:{type:'string'},
    seo_keywords:{type:'string'}, hashtags:{type:'string'}, image_text:{type:'string'},
    image_prompt:{type:'string'}, cta:{type:'string'}
  }, required:['title','evergreen_text','description','seo_keywords','hashtags','image_text','image_prompt','cta']
};

app.get('/health',(req,res)=>res.json({ok:true,app:'MP GPT',model:MODEL}));
app.post('/generate', async (req,res)=>{
  try {
    const topic=String(req.body?.topic||'').trim();
    const platform=String(req.body?.platform||'Facebook').trim();
    if(!topic) return res.status(400).json({error:'Falta el tema'});
    if(topic.length>1000) return res.status(400).json({error:'El tema es demasiado largo'});
    const userInput=`Tema: ${topic}\nPlataforma principal: ${platform}\nGenera una pieza completa y lista para publicar. Adapta el tono y los hashtags a la plataforma, pero mantén el estilo de Mentiras Piadosas.`;
    const response=await client.responses.create({
      model:MODEL, store:false, instructions,
      input:userInput,
      text:{format:{type:'json_schema',name:'mp_gpt_post',strict:true,schema}}
    });
    const data=JSON.parse(response.output_text);
    res.json({data,model:MODEL});
  } catch(err){
    console.error(err);
    res.status(500).json({error:err?.message||'Error generando contenido'});
  }
});

const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`MP GPT server listening on ${port}`));
